export class Scoreboard {
    constructor(scene) {
        this.relatedScene = scene;
        this.score = 0;
    }

    create() {
        this.scoreText = this.relatedScene.add.text(16, 16, 'Points: 0', { 
            fontSize: '15px',
            fill: '#fff',
            fontFamily: 'verdana, arial, sans-serif'
        });
    }

    sumarPuntos(puntos) {
        this.score += puntos;
        this.scoreText.setText('Points: ' + this.score);
    }

}