import { Scoreboard } from '../componenentes/scoreboard.js';

export class Gameover extends Phaser.Scene {

    constructor() {
        super({ key:'gameover' })
    }

    init() {
        this.scoreboard = new Scoreboard(this);
    }

    preload() {
        this.load.image('fondo-gameo', '../assets/GAMEOVER.jpg');
        this.load.image('boton1-gameo', '../assets/BotonRestart.png');
        this.load.image('boton2-gameo', '../assets/BotonMenu.png');
        
    }

    create() {
        this.add.image(200, 400, 'fondo-gameo');

        const restart = this.add.zone(50, 400, 300, 100);
       	restart.setOrigin(0);
        restart.setInteractive();
        restart.once('pointerdown', this.opcionPulsada1, this);
        this.add.image(200, 450, 'boton1-gameo');

        const menu = this.add.zone(50, 550, 300, 100);
       	menu.setOrigin(0);
        menu.setInteractive();
        menu.once('pointerdown', this.opcionPulsada2, this);
        this.add.image(200, 600, 'boton2-gameo');

    }

    update() {

    }

    opcionPulsada1() {
        this.scene.start('game');
        this.scene.pause();
    }

    opcionPulsada2() {
        this.scene.start('menu');
        this.scene.pause();
    }

}