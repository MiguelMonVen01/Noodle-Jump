export class Menu extends Phaser.Scene {

    constructor() {
        super({ key:'menu' })
    }

    preload() {
        this.load.image('fondo-menu', '../assets/MENU.jpg');
    }

    create() {
        this.add.image(200, 400, 'fondo-menu');

        const start = this.add.zone(40, 386, 300, 50);
       	start.setOrigin(0);
        start.setInteractive();
        start.once('pointerdown', this.opcionPulsada1, this);

        const web = this.add.zone(40, 486, 300, 50);
       	web.setOrigin(0);
        web.setInteractive();
        web.once('pointerdown', this.opcionPulsada2, this);
    }

    opcionPulsada1() {
        this.scene.start('game');
        this.scene.pause();
    }

    opcionPulsada2() {

    var url = 'http://mmonferrer.proyectosbarreira.com/proyecto-final/';

    var s = window.open(url, '_blank');

    if (s && s.focus)
    {
        s.focus();
    }
    else if (!s)
    {
        window.location.href = url;
    }
    }

}