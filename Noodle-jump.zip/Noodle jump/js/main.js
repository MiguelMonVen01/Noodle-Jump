import { Game } from './juego.js'
import { Gameover } from './gameover.js'
import { Menu } from './menu.js'

const config = {
    type: Phaser.AUTO,
    width: 400,
    height: 800,
    scene: [Menu, Game, Gameover],
    physics: {
        default: 'arcade',
        arcade: {debug: false}
    }
}
var game = new Phaser.Game(config);