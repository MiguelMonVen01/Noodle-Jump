import { Scoreboard } from "./../componenentes/scoreboard.js";

let fondo;
let separacion;
let plat;
let rand;
let noody;
let cursors;

export class Game extends Phaser.Scene {

    constructor() {
        super({ key:'game' })
    }

    init() {
        this.scoreboard = new Scoreboard(this);
    }

    preload() {

        this.load.image('fondo', '../assets/fondo.jpg');
        this.load.image('palillo', '../assets/palillo.png');
        this.load.spritesheet('noody', 
        '../assets/principal.png',
        { frameWidth: 256, frameHeight: 256 }

    );

    }

    create() {

        this.physics.world.setBoundsCollision(true, true, true, false)

        fondo = this.physics.add.sprite(200, 0, 'fondo');
        fondo.setVelocityY(20);

        noody = this.physics.add.image(150,0,'noody').setOrigin(0,0).setScale(0.3);
        noody.setGravityY(100);
        noody.setCollideWorldBounds(true);
        noody.body.checkCollision.up = false;
        noody.body.checkCollision.left = false;
        noody.body.checkCollision.right = false;

        for(let i = 0; i < 2000; i++) {
            separacion = (800 / 3) * -i;
            rand = Phaser.Math.Between(0, 360);
            plat = this.physics.add.image(rand,separacion,'palillo').setOrigin(0,-80);
            plat.setVelocityY(150);
            plat.setScale(0.1);
            plat.setImmovable();
            this.physics.add.collider(noody, plat,this.salto, null, this);

        }

        this.scoreboard.create();

        cursors = this.input.keyboard.createCursorKeys();
    }

    salto() {
        this.scoreboard.sumarPuntos(1);
        noody.setVelocityY(-180);
    }

    update() {

        if (fondo.y > 800) {
            fondo.setY(0);
        }


       if (cursors.left.isDown){
            noody.setVelocityX(-100);
            noody.setFrame(1);

        }
        else if (cursors.right.isDown){
            noody.setVelocityX(100);
            noody.setFrame(2);
        }
        else{
            noody.setVelocityX(0);
            noody.setFrame(0);
        }

        if (noody.y > 720) {
            this.scene.start('gameover');
            this.scene.pause();
        }

        
        if (noody.y < 100) {
            fondo.setVelocityY(100);
            plat.setVelocityY(600);
        }else if (noody.y < 200) {
            plat.setVelocityY(300);
            fondo.setVelocityY(50);
        }else {
            plat.setVelocityY(150);
            fondo.setVelocityY(20);
        }
        
    }

}